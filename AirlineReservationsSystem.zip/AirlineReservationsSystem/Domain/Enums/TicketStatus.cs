﻿namespace AirlineReservationsSystem.Domain.Enums
{
    public enum TicketStatus
    {
        Reserved, // محجوز
        Canceled, // ملغي
        CheckedIn, // تسجيل الوصول
        Issued,
        Cancelled
    }
}
