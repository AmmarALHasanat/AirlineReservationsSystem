﻿namespace AirlineReservationsSystem.Domain.Enums
{
    public enum BookingStatus
    {
        Confirmed,
        Canceled,
        Pending
    }
}
