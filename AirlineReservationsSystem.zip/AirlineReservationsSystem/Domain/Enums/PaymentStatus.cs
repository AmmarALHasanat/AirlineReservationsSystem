﻿namespace AirlineReservationsSystem.Domain.Enums
{
    public enum PaymentStatus
    {
        Refund,
        Pending,
        Confirmed,
        Cancelled,
    }
}
