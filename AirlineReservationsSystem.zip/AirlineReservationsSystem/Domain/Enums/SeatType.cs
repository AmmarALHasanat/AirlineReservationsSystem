﻿namespace AirlineReservationsSystem.Domain.Enums
{
    public enum SeatType
    {
        Economy,
        Business,
        FirstClass
    }
}
