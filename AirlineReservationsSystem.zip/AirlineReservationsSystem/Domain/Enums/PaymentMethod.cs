﻿namespace AirlineReservationsSystem.Domain.Enums
{
    public enum PaymentMethod
    {
        PayPal
    }
}
